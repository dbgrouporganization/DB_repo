package UI;

public enum Users {CUSTOMER, VEHICLELOOKUP, ADMIN, MARKETING
}
