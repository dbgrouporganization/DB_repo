package Appl;

import java.sql.Connection;

public class SQLQueries {
    Connection conn;

    public SQLQueries(Connection conn){
        this.conn = conn;
    }
    //public SQLgetCustomerView()
}
